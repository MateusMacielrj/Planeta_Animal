

function PedidoFinalizado() {
  return (
    <main className="pedido-finalizado" id="pedido-finalizado">

      <section className="confirmacao-card" id="confirmacao-pedido">

        <div className="confirmacao-icone" id="icone-confirmacao">
          ✓
        </div>

        <h1 id="titulo-confirmacao">
          Pedido Finalizado!
        </h1>

        <p className="mensagem-confirmacao" id="mensagem-confirmacao">
          O pedido foi registrado com sucesso.
        </p>

        <section className="resumo-pedido" id="resumo-pedido">

          <div className="resumo-item">
            <span>Número do Pedido:</span>
            <strong id="numero-pedido">000123</strong>
          </div>

          <div className="resumo-item">
            <span>Cliente:</span>
            <strong id="nome-cliente">João da Silva</strong>
          </div>

          <div className="resumo-item">
            <span>Data:</span>
            <strong id="data-pedido">06/10/2026</strong>
          </div>

          <div className="resumo-item">
            <span>Total:</span>
            <strong id="valor-total">R$ 325,00</strong>
          </div>

        </section>

        <section className="acoes-pedido" id="acoes-pedido">

          <button
            type="button"
            className="botao-novo-pedido"
            id="botao-novo-pedido"
          >
            Novo Pedido
          </button>

          <button
            type="button"
            className="botao-visualizar-pedido"
            id="botao-visualizar-pedido"
          >
            Visualizar Pedido
          </button>

        </section>

      </section>

    </main>
  );
}

export default PedidoFinalizado;