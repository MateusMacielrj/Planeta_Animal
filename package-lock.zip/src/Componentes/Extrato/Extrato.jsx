import "./Extrato.css";

function Extrato() {
  return (
    <main className="extrato" id="extrato">

      {/* CABEÇALHO */}
      <header className="extrato-header" id="extrato-header">

        <div>
          <h1>Extrato</h1>

          <p>
            Consulte as movimentações financeiras da loja.
          </p>
        </div>

      </header>


      {/* RESUMO FINANCEIRO */}
      <section
        className="resumo-extrato"
        id="resumo-extrato"
      >

        {/* SALDO */}
        <article
          className="resumo-card saldo-atual"
          id="saldo-atual"
        >

          <span>Saldo Atual</span>

          <strong id="valor-saldo">
            R$ 4.250,00
          </strong>

        </article>


        {/* ENTRADAS */}
        <article
          className="resumo-card total-entradas"
          id="total-entradas"
        >

          <span>Total de Entradas</span>

          <strong id="valor-entradas">
            R$ 5.800,00
          </strong>

        </article>


        {/* SAÍDAS */}
        <article
          className="resumo-card total-saidas"
          id="total-saidas"
        >

          <span>Total de Saídas</span>

          <strong id="valor-saidas">
            R$ 1.550,00
          </strong>

        </article>

      </section>


      {/* FILTROS */}
      <section
        className="filtros-extrato"
        id="filtros-extrato"
      >

        {/* PERÍODO */}
        <div className="campo-extrato">

          <label htmlFor="periodo-extrato">
            Período:
          </label>

          <select id="periodo-extrato">

            <option value="">
              Selecione
            </option>

            <option value="hoje">
              Hoje
            </option>

            <option value="semana">
              Esta semana
            </option>

            <option value="mes">
              Este mês
            </option>

            <option value="personalizado">
              Personalizado
            </option>

          </select>

        </div>


        {/* DATA */}
        <div className="campo-extrato">

          <label htmlFor="data-inicial">
            Data Inicial:
          </label>

          <input
            id="data-inicial"
            type="date"
          />

        </div>


        {/* TIPO */}
        <div className="campo-extrato">

          <label htmlFor="tipo-movimentacao">
            Tipo:
          </label>

          <select id="tipo-movimentacao">

            <option value="">
              Todos
            </option>

            <option value="entrada">
              Entrada
            </option>

            <option value="saida">
              Saída
            </option>

          </select>

        </div>


        {/* BOTÃO */}
        <button
          type="button"
          className="botao-filtrar"
          id="botao-filtrar-extrato"
        >
          Filtrar
        </button>

      </section>


      {/* LISTA DE MOVIMENTAÇÕES */}
      <section
        className="lista-extrato"
        id="lista-extrato"
      >

        <header className="lista-extrato-header">

          <h2>
            Movimentações
          </h2>

        </header>


        {/* CABEÇALHO DA LISTA */}
        <div
          className="movimentacao-linha movimentacao-cabecalho"
          id="cabecalho-movimentacoes"
        >

          <span>Data</span>

          <span>Descrição</span>

          <span>Tipo</span>

          <span>Pagamento</span>

          <span>Valor</span>

        </div>


        {/* MOVIMENTAÇÃO 1 */}
        <article
          className="movimentacao-linha"
          id="movimentacao-001"
        >

          <span>
            06/10/2026
          </span>

          <strong>
            Venda Pedido #000123
          </strong>

          <span className="movimentacao-entrada">
            Entrada
          </span>

          <span>
            PIX
          </span>

          <strong className="valor-entrada">
            + R$ 325,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 2 */}
        <article
          className="movimentacao-linha"
          id="movimentacao-002"
        >

          <span>
            06/10/2026
          </span>

          <strong>
            Compra de mercadorias
          </strong>

          <span className="movimentacao-saida">
            Saída
          </span>

          <span>
            PIX
          </span>

          <strong className="valor-saida">
            - R$ 800,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 3 */}
        <article
          className="movimentacao-linha"
          id="movimentacao-003"
        >

          <span>
            05/10/2026
          </span>

          <strong>
            Venda Pedido #000121
          </strong>

          <span className="movimentacao-entrada">
            Entrada
          </span>

          <span>
            Dinheiro
          </span>

          <strong className="valor-entrada">
            + R$ 150,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 4 */}
        <article
          className="movimentacao-linha"
          id="movimentacao-004"
        >

          <span>
            05/10/2026
          </span>

          <strong>
            Pagamento fornecedor
          </strong>

          <span className="movimentacao-saida">
            Saída
          </span>

          <span>
            Transferência
          </span>

          <strong className="valor-saida">
            - R$ 750,00
          </strong>

        </article>

      </section>


      {/* SALDO DO PERÍODO */}
      <section
        className="saldo-periodo"
        id="saldo-periodo"
      >

        <span>
          Saldo do período:
        </span>

        <strong id="valor-saldo-periodo">
          R$ 1.275,00
        </strong>

      </section>

    </main>
  );
}

export default Extrato;