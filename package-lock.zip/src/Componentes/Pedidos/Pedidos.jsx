import { useNavigate } from "react-router-dom";
import { useState } from "react";

function Pedidos({ pedidos }) {
  const navigate = useNavigate();

  // Estado da busca
  const [busca, setBusca] = useState("");

  // Filtrar pedidos pelo nome do cliente
  const pedidosFiltrados = pedidos.filter((pedido) =>
    pedido.cliente.nome
      .toLowerCase()
      .includes(busca.trim().toLowerCase())
  );

  return (
    <main className="pedidos" id="pedidos">
      {/* CABEÇALHO */}
      <header className="pedidos-header">
        <div>
          <h1>Pedidos</h1>
          <p>Consulte os pedidos realizados.</p>
        </div>

        <button
          type="button"
          className="botao-novo-pedido"
          id="botao-novo-pedido"
          onClick={() => navigate("/novo-pedido")}
        >
          + Novo Pedido
        </button>
      </header>

      {/* BUSCA E FILTROS */}
      <section className="filtros-pedidos" id="filtros-pedidos">
        <div className="campo-busca">
          <label htmlFor="buscar-pedido">
            Buscar pedido:
          </label>

          <input
            id="buscar-pedido"
            type="text"
            placeholder="Número do pedido ou nome do cliente"
            value={busca}
            onChange={(event) => setBusca(event.target.value)}
          />
        </div>

        <div className="campo-filtro">
          <label htmlFor="filtro-status">Status:</label>

          <select id="filtro-status" defaultValue="">
            <option value="">Todos</option>
            <option value="finalizado">Finalizado</option>
            <option value="pendente">Pendente</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>

        <div className="campo-filtro">
          <label htmlFor="filtro-data">Data:</label>

          <input id="filtro-data" type="date" />
        </div>
      </section>

      {/* LISTA DE PEDIDOS */}
      <section className="lista-pedidos" id="lista-pedidos">
        <header className="lista-pedidos-header">
          <h2>Pedidos realizados</h2>
        </header>

        {pedidos.length === 0 ? (
          <p className="nenhum-pedido">
            Nenhum pedido cadastrado.
          </p>
        ) : pedidosFiltrados.length === 0 ? (
          <p className="nenhum-pedido">
            Nenhum pedido encontrado.
          </p>
        ) : (
          pedidosFiltrados.map((pedido) => {
            const numeroPedido = String(
              pedidos.findIndex((item) => item.id === pedido.id) + 1
            ).padStart(6, "0");

            return (
              <article className="pedido-item" key={pedido.id}>
                <div className="pedido-numero">
                  <span>Pedido</span>
                  <strong>{numeroPedido}</strong>
                </div>

                <div className="pedido-cliente">
                  <span>Cliente</span>
                  <strong>{pedido.cliente.nome}</strong>
                </div>

                <div className="pedido-data">
                  <span>Data</span>
                  <strong>{pedido.dataCriacao}</strong>
                </div>

                <div className="pedido-total">
                  <span>Total</span>
                  <strong>
                    {pedido.total.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })}
                  </strong>
                </div>

                <div className="pedido-status">
                  <span>Status</span>
                  <strong className="status-pendente">
                    Pendente
                  </strong>
                </div>

                <div className="pedido-acoes">
                  <button
                    type="button"
                    className="botao-visualizar"
                    onClick={() =>
                      navigate("/detalhespedido", {
                        state: { pedido },
                      })
                    }
                  >
                    Visualizar
                  </button>
                </div>
              </article>
            );
          })
        )}
      </section>
    </main>
  );
}

export default Pedidos;