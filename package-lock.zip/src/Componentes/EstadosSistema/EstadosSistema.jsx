import "./EstadosSistema.css";

function EstadosSistema() {
  return (
    <main
      className="estados-sistema"
      id="estados-sistema"
    >

      {/* CABEÇALHO */}
      <header
        className="estados-header"
        id="estados-header"
      >

        <div>
          <h1>Estados do Sistema</h1>

          <p>
            Consulte o estado atual dos serviços e funcionalidades do sistema.
          </p>
        </div>

        <span
          className="status-geral sistema-operacional"
          id="status-geral"
        >
          Sistema operacional
        </span>

      </header>

      {/* STATUS DOS SERVIÇOS */}
      <section
        className="servicos-status"
        id="servicos-status"
      >

        <h2>Status dos Serviços</h2>

        {/* FRONT-END */}
        <article
          className="servico-card servico-online"
          id="status-frontend"
        >

          <div className="servico-indicador">
            <span
              className="indicador indicador-verde"
              id="indicador-frontend"
            ></span>
          </div>

          <div className="servico-info">

            <h3>Front-end</h3>

            <p>
              Aplicação funcionando normalmente.
            </p>

            <span
              className="servico-status"
              id="texto-status-frontend"
            >
              Online
            </span>

          </div>

        </article>

        {/* BACK-END */}
        <article
          className="servico-card servico-online"
          id="status-backend"
        >

          <div className="servico-indicador">
            <span
              className="indicador indicador-verde"
              id="indicador-backend"
            ></span>
          </div>

          <div className="servico-info">

            <h3>Back-end</h3>

            <p>
              Serviço disponível e respondendo normalmente.
            </p>

            <span
              className="servico-status"
              id="texto-status-backend"
            >
              Online
            </span>

          </div>

        </article>

        {/* BANCO DE DADOS */}
        <article
          className="servico-card servico-online"
          id="status-banco"
        >

          <div className="servico-indicador">
            <span
              className="indicador indicador-verde"
              id="indicador-banco"
            ></span>
          </div>

          <div className="servico-info">

            <h3>Banco de Dados</h3>

            <p>
              Banco de dados conectado normalmente.
            </p>

            <span
              className="servico-status"
              id="texto-status-banco"
            >
              Conectado
            </span>

          </div>

        </article>

        {/* CONEXÃO */}
        <article
          className="servico-card servico-online"
          id="status-conexao"
        >

          <div className="servico-indicador">
            <span
              className="indicador indicador-verde"
              id="indicador-conexao"
            ></span>
          </div>

          <div className="servico-info">

            <h3>Conexão</h3>

            <p>
              Conexão com a internet funcionando normalmente.
            </p>

            <span
              className="servico-status"
              id="texto-status-conexao"
            >
              Conectado
            </span>

          </div>

        </article>

      </section>

      {/* ÚLTIMA VERIFICAÇÃO */}
      <section
        className="ultima-verificacao"
        id="ultima-verificacao"
      >

        <div>
          <span>Última verificação</span>

          <strong id="data-verificacao">
            06/10/2026 às 16:30
          </strong>
        </div>

        <button
          type="button"
          className="botao-atualizar-status"
          id="botao-atualizar-status"
        >
          Atualizar Status
        </button>

      </section>

      {/* INFORMAÇÕES DO SISTEMA */}
      <section
        className="informacoes-sistema"
        id="informacoes-sistema"
      >

        <h2>Informações do Sistema</h2>

        <div className="informacoes-grid">

          <div className="informacao-item">
            <span>Versão do sistema</span>

            <strong id="versao-sistema">
              1.0.0
            </strong>
          </div>

          <div className="informacao-item">
            <span>Ambiente</span>

            <strong id="ambiente-sistema">
              Produção
            </strong>
          </div>

          <div className="informacao-item">
            <span>Status geral</span>

            <strong
              className="status-operacional"
              id="status-operacional"
            >
              Operacional
            </strong>
          </div>

        </div>

      </section>

    </main>
  );
}

export default EstadosSistema;