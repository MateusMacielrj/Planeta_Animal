

function Comanda() {
  return (
    <main className="comanda">

      {/* CABEÇALHO */}
      <header className="comanda-header">
        <h1>Planeta Animal</h1>
        <p>CNPJ: 00.000.000/0001-00</p>
        <p>21 90000 0000</p>
      </header>

      {/* IDENTIFICAÇÃO DO PEDIDO */}
      <section className="pedido-info">
        <h2>Pedido Nº 000123</h2>
        <p>Data: 29/09/2026</p>
      </section>

      {/* DADOS DO CLIENTE */}
      <section className="cliente-info">
        <h2>Dados do Cliente</h2>

        <div className="cliente-dados">
          <p>Cliente:</p>
          <p>Telefone:</p>
          <p>Endereço:</p>
          <p>Complemento:</p>
        </div>
      </section>

      {/* PRODUTOS */}
      <section className="produtos-info">
        <h2>Produtos</h2>

        <div className="produtos-header">
          <p>Código</p>
          <p>Produto</p>
          <p>QTD</p>
          <p>Unidade</p>
          <p>Valor</p>
          <p>Subtotal</p>
        </div>
      </section>

      {/* TOTAL */}
      <section className="pedido-total">
        <h2>Total:</h2>
        <p>Pagamento:</p>
        <p>OBS: Entrega após as 18 horas</p>
      </section>

      {/* RODAPÉ */}
      <footer className="comanda-footer">
        <h2>Obrigado pela preferência</h2>
        <p>Planeta Animal</p>
      </footer>

    </main>
  );
}

export default Comanda;