

function DetalhesPedido() {
  return (
    <main className="detalhes-pedido" id="detalhes-pedido">

      {/* CABEÇALHO */}
      <header className="detalhes-header" id="detalhes-header">

        <div>
          <h1>Detalhes do Pedido</h1>
          <p>Confira todas as informações do pedido.</p>
        </div>

        <span
          className="detalhes-status status-finalizado"
          id="status-pedido"
        >
          Finalizado
        </span>

      </header>

      {/* INFORMAÇÕES DO PEDIDO */}
      <section
        className="card detalhes-info-pedido"
        id="detalhes-info-pedido"
      >

        <h2>Informações do Pedido</h2>

        <div className="informacoes-grid">

          <div className="informacao-item">
            <span>Número do Pedido</span>
            <strong id="numero-pedido">000123</strong>
          </div>

          <div className="informacao-item">
            <span>Data</span>
            <strong id="data-pedido">06/10/2026</strong>
          </div>

          <div className="informacao-item">
            <span>Horário</span>
            <strong id="horario-pedido">14:35</strong>
          </div>

        </div>

      </section>

      {/* DADOS DO CLIENTE */}
      <section
        className="card detalhes-cliente"
        id="detalhes-cliente"
      >

        <h2>Dados do Cliente</h2>

        <div className="cliente-grid">

          <div className="informacao-item">
            <span>Nome</span>
            <strong id="nome-cliente">
              João da Silva
            </strong>
          </div>

          <div className="informacao-item">
            <span>Telefone</span>
            <strong id="telefone-cliente">
              (21) 99999-9999
            </strong>
          </div>

          <div className="informacao-item">
            <span>Endereço</span>
            <strong id="endereco-cliente">
              Rua das Flores, 100
            </strong>
          </div>

          <div className="informacao-item">
            <span>Complemento</span>
            <strong id="complemento-cliente">
              Casa
            </strong>
          </div>

        </div>

      </section>

      {/* PRODUTOS */}
      <section
        className="card detalhes-produtos"
        id="detalhes-produtos"
      >

        <h2>Produtos do Pedido</h2>

        <div className="produtos-tabela">

          {/* CABEÇALHO */}
          <div className="produto-linha produto-cabecalho">

            <span>Código</span>
            <span>Produto</span>
            <span>Quantidade</span>
            <span>Unidade</span>
            <span>Valor Unitário</span>
            <span>Subtotal</span>

          </div>

          {/* PRODUTO 1 */}
          <article
            className="produto-linha"
            id="produto-001"
          >

            <span>001</span>

            <strong>
              Ração Premium Adultos
            </strong>

            <span>2</span>

            <span>Kg</span>

            <span>R$ 25,00</span>

            <strong>
              R$ 50,00
            </strong>

          </article>

          {/* PRODUTO 2 */}
          <article
            className="produto-linha"
            id="produto-002"
          >

            <span>002</span>

            <strong>
              Ração para Gatos
            </strong>

            <span>5</span>

            <span>Kg</span>

            <span>R$ 30,00</span>

            <strong>
              R$ 150,00
            </strong>

          </article>

          {/* PRODUTO 3 */}
          <article
            className="produto-linha"
            id="produto-003"
          >

            <span>003</span>

            <strong>
              Petisco para Cães
            </strong>

            <span>5</span>

            <span>Unidade</span>

            <span>R$ 25,00</span>

            <strong>
              R$ 125,00
            </strong>

          </article>

        </div>

      </section>

      {/* PAGAMENTO */}
      <section
        className="card detalhes-pagamento"
        id="detalhes-pagamento"
      >

        <h2>Pagamento</h2>

        <div className="pagamento-grid">

          <div className="informacao-item">
            <span>Forma de Pagamento</span>

            <strong id="forma-pagamento">
              PIX
            </strong>
          </div>

          <div className="informacao-item">
            <span>Observação</span>

            <strong id="observacao-pedido">
              Entrega após as 18 horas
            </strong>
          </div>

        </div>

      </section>

      {/* TOTAL */}
      <section
        className="card detalhes-total"
        id="detalhes-total"
      >

        <span>Total do Pedido</span>

        <strong id="total-pedido">
          R$ 325,00
        </strong>

      </section>

      {/* AÇÕES */}
      <section
        className="detalhes-acoes"
        id="detalhes-acoes"
      >

        <button
          type="button"
          className="botao-voltar"
          id="botao-voltar-pedidos"
        >
          Voltar para Pedidos
        </button>

        <button
          type="button"
          className="botao-imprimir"
          id="botao-imprimir-pedido"
        >
          Imprimir Comanda
        </button>

      </section>

    </main>
  );
}

export default DetalhesPedido;