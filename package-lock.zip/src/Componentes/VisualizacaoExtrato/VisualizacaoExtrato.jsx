import "./VisualizacaoExtrato.css";

function VisualizacaoExtrato() {
  return (
    <main
      className="visualizacao-extrato"
      id="visualizacao-extrato"
    >

      {/* CABEÇALHO */}
      <header
        className="visualizacao-header"
        id="visualizacao-header"
      >

        <div className="empresa-extrato">
          <h1 id="nome-empresa">
            Planeta Animal
          </h1>

          <p id="cnpj-empresa">
            CNPJ: 00.000.000/0001-00
          </p>

          <p id="telefone-empresa">
            Telefone: (21) 90000-0000
          </p>
        </div>

        <div className="titulo-relatorio">
          <h2>
            Extrato Financeiro
          </h2>

          <p>
            Relatório de movimentações
          </p>
        </div>

      </header>


      {/* PERÍODO */}
      <section
        className="periodo-relatorio"
        id="periodo-relatorio"
      >

        <div className="periodo-item">
          <span>Período Inicial</span>

          <strong id="data-inicial-relatorio">
            01/10/2026
          </strong>
        </div>

        <div className="periodo-item">
          <span>Período Final</span>

          <strong id="data-final-relatorio">
            06/10/2026
          </strong>
        </div>

      </section>


      {/* RESUMO */}
      <section
        className="resumo-relatorio"
        id="resumo-relatorio"
      >

        <article
          className="resumo-relatorio-item entrada"
          id="relatorio-entradas"
        >

          <span>
            Total de Entradas
          </span>

          <strong id="total-entradas-relatorio">
            R$ 5.800,00
          </strong>

        </article>


        <article
          className="resumo-relatorio-item saida"
          id="relatorio-saidas"
        >

          <span>
            Total de Saídas
          </span>

          <strong id="total-saidas-relatorio">
            R$ 1.550,00
          </strong>

        </article>


        <article
          className="resumo-relatorio-item saldo"
          id="relatorio-saldo"
        >

          <span>
            Saldo do Período
          </span>

          <strong id="saldo-relatorio">
            R$ 4.250,00
          </strong>

        </article>

      </section>


      {/* MOVIMENTAÇÕES */}
      <section
        className="movimentacoes-relatorio"
        id="movimentacoes-relatorio"
      >

        <header className="relatorio-section-header">

          <h2>
            Movimentações
          </h2>

        </header>


        {/* CABEÇALHO DA TABELA */}
        <div
          className="relatorio-linha relatorio-cabecalho"
          id="cabecalho-relatorio"
        >

          <span>Data</span>

          <span>Descrição</span>

          <span>Tipo</span>

          <span>Pagamento</span>

          <span>Valor</span>

        </div>


        {/* MOVIMENTAÇÃO 1 */}
        <article
          className="relatorio-linha"
          id="relatorio-movimentacao-001"
        >

          <span>
            06/10/2026
          </span>

          <strong>
            Venda Pedido #000123
          </strong>

          <span className="tipo-entrada">
            Entrada
          </span>

          <span>
            PIX
          </span>

          <strong className="valor-entrada">
            + R$ 325,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 2 */}
        <article
          className="relatorio-linha"
          id="relatorio-movimentacao-002"
        >

          <span>
            06/10/2026
          </span>

          <strong>
            Compra de mercadorias
          </strong>

          <span className="tipo-saida">
            Saída
          </span>

          <span>
            PIX
          </span>

          <strong className="valor-saida">
            - R$ 800,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 3 */}
        <article
          className="relatorio-linha"
          id="relatorio-movimentacao-003"
        >

          <span>
            05/10/2026
          </span>

          <strong>
            Venda Pedido #000121
          </strong>

          <span className="tipo-entrada">
            Entrada
          </span>

          <span>
            Dinheiro
          </span>

          <strong className="valor-entrada">
            + R$ 150,00
          </strong>

        </article>


        {/* MOVIMENTAÇÃO 4 */}
        <article
          className="relatorio-linha"
          id="relatorio-movimentacao-004"
        >

          <span>
            05/10/2026
          </span>

          <strong>
            Pagamento fornecedor
          </strong>

          <span className="tipo-saida">
            Saída
          </span>

          <span>
            Transferência
          </span>

          <strong className="valor-saida">
            - R$ 750,00
          </strong>

        </article>

      </section>


      {/* TOTAL FINAL */}
      <section
        className="total-final-relatorio"
        id="total-final-relatorio"
      >

        <span>
          Saldo Final
        </span>

        <strong id="saldo-final">
          R$ 4.250,00
        </strong>

      </section>


      {/* AÇÕES */}
      <section
        className="acoes-relatorio"
        id="acoes-relatorio"
      >

        <button
          type="button"
          className="botao-voltar-extrato"
          id="botao-voltar-extrato"
        >
          Voltar
        </button>

        <button
          type="button"
          className="botao-imprimir-extrato"
          id="botao-imprimir-extrato"
        >
          Imprimir Extrato
        </button>

      </section>


      {/* RODAPÉ */}
      <footer
        className="rodape-relatorio"
        id="rodape-relatorio"
      >

        <p>
          Planeta Animal
        </p>

        <span>
          Relatório gerado pelo sistema
        </span>

      </footer>

    </main>
  );
}

export default VisualizacaoExtrato;